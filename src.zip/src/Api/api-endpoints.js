
export const TRANSFORMERS_API = {
    'DOMAIN_CURRENCY': '/fpts/domainCurrencyMapping',
}

export const MAT_API = {
    'UPLOAD_CSV': '/fpts/offer/upload',
    'CREAT_COUPON': '/fpts/offer/create',
    'GENERATE_OR_VALIDATE_COUPON': '/fpts/offer/generate-coupon',
    'APPROVE_COUPON': '/fpts/offer/approve',
}