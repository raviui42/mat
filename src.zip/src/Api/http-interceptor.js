
function successHandler(response) {
    console.log('success handler', response);
}

function errorHandler(response) {
    console.log('error handler', response);
}

function catchHandler(response) {
    console.log('catch handler', response);
}

function apiCall(method, url, body) {
    const requestObj = {
        method: method,
        headers: {
            'Content-Type': 'application/json',
        }
    };
    
    if (method === 'POST') {
        requestObj.body = JSON.stringify(body);
    };

    if(headers){
        requestObj.headers = {
            ...requestObj.headers,
            headers
        }
    }

    fetch(url, requestObj)
        .then(res => res.json())
        .then(successHandler, errorHandler)
        .catch(catchHandler);
}

export function get(url, headers) {
    const METHOD_TYPE = 'GET'
    if (headers) {
        apiCall(METHOD_TYPE, url, headers);
    } else {
        apiCall(METHOD_TYPE, url);
    }
}

export function post(url, body, headers) {
    const METHOD_TYPE = 'POST';
    if (headers) {
        apiCall(METHOD_TYPE, url, body, headers);
    } else {
        apiCall(METHOD_TYPE, url, body);
    }

}

