export const IMAGE_SRC_CONSTANTS = {
    'TILA_LOGO': require('../../Assets/Images/logo-tila.png'),
}
