import React from 'react';
import { IMAGE_SRC_CONSTANTS } from './images.contants';
// import { Avatar } from 'antd';

export default class MatImage extends React.Component {
    constructor(props){
        super(props);
        console.log('Mat Image', IMAGE_SRC_CONSTANTS[this.props.name]);
        this.state = {};
    }

    render(){
        return (<img src={IMAGE_SRC_CONSTANTS[this.props.name]} alt={this.props.name} />);
    }
}