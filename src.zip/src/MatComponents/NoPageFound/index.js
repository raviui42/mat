/*eslint-disable*/
import React from 'react';
// import Images from '../Images';

const NoPageFound = () => (
  <div style={{
    display: 'flex', width: '100%', justifyContent: 'center', height: '80vh', verticalAlign : 'middle',
  }}>
    <img src={'Images.COMING_SOON'} alt="Coming Soon" />
  </div>
);

export default NoPageFound;
