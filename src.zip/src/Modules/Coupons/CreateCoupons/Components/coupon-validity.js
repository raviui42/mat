import React, { Component } from 'react';
import DateRange from '../../../../MatComponents/MatRangePicker';
import MatCheckBox from '../../../../MatComponents/MatCheckbox';
import MatTimepicker from '../../../../MatComponents/MatTimepicker';

export default class CouponValidity extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (<div>
            <h4>Coupon Validity</h4>
            <DateRange />
            <MatCheckBox />
            <MatTimepicker />
            <MatTimepicker />
        </div>);
    }
}
