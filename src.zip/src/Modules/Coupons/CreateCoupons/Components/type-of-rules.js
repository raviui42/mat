import React, { Component } from 'react';
import { Row, Col, Radio } from 'antd';
import { priceSlabsObjectModalEnum } from '../../coupons-constants';

export default class TypeOfRules extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: 1,
        };
    }

    onChange = e => {
        console.log('radio checked', e.target.value);
        this.setState({
            value: e.target.value,
        });
    };

    render() {
        const radioStyle = {
            display: 'block',
            height: '30px',
            lineHeight: '30px',
        };
        return (
            <div>
                <Radio.Group style={{ width: '100%' }} onChange={this.onChange} value={this.state.value}>
                    <Row>
                        <Col span={12}>
                            <h4>Item Level Rule (In Values)</h4>
                            <Radio style={radioStyle} value={priceSlabsObjectModalEnum[0]}>Flat Value</Radio>
                            <Radio style={radioStyle} value={priceSlabsObjectModalEnum[1]}>Variable Value</Radio>
                        </Col>
                        <Col span={12}>
                            <h4>Item Level Rule (In Percentage)</h4>
                            <Radio style={radioStyle} value={priceSlabsObjectModalEnum[2]}>Percentage</Radio>
                            <Radio style={radioStyle} value={priceSlabsObjectModalEnum[3]}>Variable Percentage</Radio>
                        </Col>
                    </Row>
                </Radio.Group>
            </div>
        );
    }
}
