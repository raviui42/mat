import { createCouponRequestObject, priceSlabsObjectModalEnum } from '../coupons-constants';

export function generateCreateCouponApiData(stateData) {
    console.log('stateData', stateData);
    const apiData = createCouponRequestObject;

    // when flash sale checkbox is selected or not selected.
    if(stateData.flashSale){
        apiData.start_date = ''; // combination of date and time from state data
        apiData.end_date = ''; // combination of date and time from state data
    } else {
        apiData.start_date = ''; // start date time will be 00:00
        apiData.end_date = ''; // start date time will be 23:59
    }

    // when brand value is not all.
    if (stateData.brands.length > 0) {
        apiData.catalog.product_attribute.brand = stateData.brands
    } else {
        delete apiData.catalog;
    }

    // push objects to price_slabs
    switch (stateData.typeOfRules) {
        case priceSlabsObjectModalEnum[0]:
            break;
        case priceSlabsObjectModalEnum[1]:
            break;
        case priceSlabsObjectModalEnum[2]:
            break;
        case priceSlabsObjectModalEnum[3]:
            break;
    }

    console.log('api Data: ', apiData);

    return apiData;
}