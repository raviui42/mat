import React, { Component } from 'react';
import { Row, Input, Button } from 'antd';
import CouponValidity from './Components/coupon-validity';
import './create-coupons.sass';
import MatCheckBox from '../../../MatComponents/MatCheckbox';
import MatCheckBoxGroup from '../../../MatComponents/MatCheckboxGroup';
import TextArea from 'antd/lib/input/TextArea';
import { generateCreateCouponApiData } from './create-coupon.service';
import TypeOfRules from './Components/type-of-rules';

class CreateCoupons extends Component {
    constructor(props) {
        super(props);
        this.state = {
            createCouponData: {
                startDate: '',
                endDate: '',
                flashSale: true,
                startTime: '',
                endTime: '',
                couponCode: '',
                csvFileLink: '',
                devices: [],
                includeDiscountedItems: false,
                userType: '',
                brands: [],
                buyerLink: '',
                paymentMethod: '',
                multiuseCriteria: '',
                minimumPurchaseValue: '',
                couponLabel: '',
                numberOfRedemptionLimit: '',
                amountOfRedemptionLimit: '',
                typeOfRules: ''
            }
        };
    }

    sentForApproval = () => {
        const stateData = this.state.createCouponData;
        const apiData = generateCreateCouponApiData(stateData);
        // this.props.createCoupon(apiData);
    }

    render() {
        return (<div className="content-container">
            <Row>
                <h3>Create Coupon</h3>
            </Row>
            <Row className="coupon-validity">
                <CouponValidity />
            </Row>
            <Row className="coupon-code">
                <h3>Enter Coupon Code:</h3>
                <h4>Enter Your Coupon Code (Alpha Numeric 10 Digit)</h4>
                <Input/>
                <MatCheckBox>Use entered coupon code.OR Uncheck to Autogenerate the code</MatCheckBox>
            </Row>
            <Row className="csv-upload">
                <h3>Upload CSV file for coupon linking</h3>
                <Button>Upload CSV File</Button>
                <Button>Download sample file</Button>
            </Row>
            <Row className="select-devices">
                <h3>Select Devices</h3>
                <MatCheckBoxGroup/>
                <MatCheckBox>Exclude already discounted (Subsidy) Items.</MatCheckBox>
            </Row>
            <Row className="user-type">
                <h3>Select User Type</h3>
                <MatCheckBox>First Time User</MatCheckBox>
                <MatCheckBox>User not transacted with Tila
                    <Input/>
                </MatCheckBox>
            </Row>
            <Row className="buyer-link">
                <MatCheckBox><h3>Buyer Link</h3></MatCheckBox>
                <div>Query Builder:</div>
                <TextArea/>
            </Row>
            <Row className="buyer-link">
                <h3>Select Brand</h3>
                <MatCheckBox>All</MatCheckBox> or <Button>View/Edit Brands</Button> 23 selected
            </Row>
            <Row className="payment-methods">
                <h3>Paymenty Method</h3>
                Radio Group for Payment Method.
            </Row>
            <Row>
                <h3>Multiuse Criteria</h3>
                <h4>Enter times of usage</h4>
                <Input/>
            </Row>
            <Row>
                <TypeOfRules/>
            </Row>
            <Row>
                <h3>Min Purchase Criteria</h3>
                <Input/>
            </Row>
            <Row>
                <h3>Coupon Label</h3>
                <TextArea></TextArea>
            </Row>
            <Row>
                <h3>Cap Coupon Redemption</h3>
                <MatCheckBox/>Limit of the number of redemptions
                <MatCheckBox/>Limit amount of redemptions
            </Row>
            <Row>
                <Button>Cancel</Button>
                <Button onClick={this.sentForApproval}>Sent For Approval</Button>
            </Row>
        </div>);
    }
}
export default CreateCoupons;
