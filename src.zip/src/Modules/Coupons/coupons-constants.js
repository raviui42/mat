export const createCouponRequestObject = {
    "start_date": "2019-08-06T14:35:05.317Z",
    "end_date": "2019-08-06T14:35:05.316Z",
    "catalog": {
        "product_attribute": {
            "brand": []
        },
    },
    "country_code": "string",
    "coupon_code": "string",
    "description": "string",
    "devices": [
        "ANDROID"
    ],
    "discount_type": "FLAT",
    "document_id": "string",
    "flash": true,
    "how_to_use": "string",
    "inclusive": true,
    "listing": {
        "listing_id": "string",
        "seller_id": "string",
        "sku_id": "string"
    },
    "max_budget": {
        "currency_code": "string",
        "money_value": {},
        "display_value": "string"
    },
    "max_count": 0,
    "max_discount": {
        "max_discount": {
            "currency_code": "",
            "money_value": {},
        },
        "max_discount_per_transaction": {
            "currency_code": "string",
            "money_value": {},
        }
    },
    "payments": [
        {
            "filtered_list": [
                "string"
            ],
            "payment_method": "CARDS"
        }
    ],
    "price_slabs": [],
    "query_builder": "string",
    "tc": "string",
    "user": "string",
    "user_profile": {
        "last_transacted_days": 0,
        "user_type": "NEW/OLD"
    },
    "min_purchase": {
        "currency_code": "string",
        "money_value": {},
        "display_value": "string"
    },
    "multi_use_count": 0,
    "name": "string",
    "offer_id": "string",
    "voucher_count": 0
}
export const priceSlabsObjectModalEnum = ['VALUE_FLAT', 'VALUE_VARIABLE', 'PERCENTAGE_FLAT', 'PERCENTAGE_VARIABLE'];

export const priceSlabsObjectModal = {
    'VALUE_FLAT': {
        "discount_type": "FLAT",
        "discount_type_value": 0,
    },
    'VALUE_VARIABLE': {
        "discount_type": "FLAT",
        "discount_type_value": 0,
        "end": 0,
        "start": 0
    },
    'PERCENTAGE_FLAT': {
        "discount_type": "PERCENTAGE",
        "discount_type_value": 0,
    },
    'PERCENTAGE_VARIABLE': {
        "discount_type": "PERCENTAGE",
        "discount_type_value": 0,
        "end": 0,
        "start": 0
    }
}

// api data to request create coupon
const createCouponModal = {
    "action": {
        "discount_percentage": 0,
        "flat_discount": {
            "currency_code": "string",
            "money_value": {},
            "display_value": "string"
        },
        "max_discount": {
            "currency_code": "string",
            "money_value": {},
            "display_value": "string"
        },
        "max_discount_per_transaction": {
            "currency_code": "string",
            "money_value": {},
            "display_value": "string"
        },
        "offer_on_mrp": true
    },
    "catalog": {
        "catalog_id": "string",
        "item_type": "string",
        "product_attribute": {
            "brand": ['<names>']
        },
        "product_id": "string",
        "variant_attribute": {},
        "variant_id": "string"
    },
    "country_code": "string",
    "coupon_code": "string",
    "description": "string",
    "devices": [
        "ANDROID"
    ],
    "discount_type": "FLAT",
    "document_id": "string",
    "end_date": "2019-08-06T14:35:05.316Z",
    "flash": true,
    "how_to_use": "string",
    "inclusive": true,
    "listing": {
        "listing_id": "string",
        "seller_id": "string",
        "sku_id": "string"
    },
    "max_budget": {
        "currency_code": "string",
        "money_value": {},
        "display_value": "string"
    },
    "max_count": 0,
    "max_discount": {
        "max_discount": {
            "currency_code": "string",
            "money_value": {},
            "display_value": "string"
        },
        "max_discount_per_transaction": {
            "currency_code": "string",
            "money_value": {},
            "display_value": "string"
        }
    },
    "min_purchase": {
        "currency_code": "string",
        "money_value": {},
        "display_value": "string"
    },
    "multi_use_count": 0,
    "name": "string",
    "offer_id": "string",
    "payments": [
        {
            "filtered_list": [
                "string"
            ],
            "payment_method": "CARDS"
        }
    ],
    "price_slabs": [
        {
            "action": {
                "discount_percentage": 0,
                "flat_discount": {
                    "currency_code": "string",
                    "money_value": {},
                    "display_value": "string"
                },
                "max_discount": {
                    "currency_code": "string",
                    "money_value": {},
                    "display_value": "string"
                },
                "max_discount_per_transaction": {
                    "currency_code": "string",
                    "money_value": {},
                    "display_value": "string"
                },
                "offer_on_mrp": true
            },
            "discount_type": "FLAT",
            "discount_type_value": 0,
            "end": 0,
            "start": 0
        }
    ],
    "query_builder": "string",
    "start_date": "2019-08-06T14:35:05.317Z",
    "tc": "string",
    "user": "string",
    "user_profile": {
        "last_transacted_days": 0,
        "user_ids": [
            "string"
        ],
        "user_type": "NEW"
    },
    "voucher_count": 0
}
