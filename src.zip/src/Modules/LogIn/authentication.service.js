/*eslint-disable*/
import { oktaBaseUrl, clientId } from './okta.config';
import { setCookie } from '../../Services/CookieService';
import constants from '../../mat.constants';

const oktaConfig = {
  client_id: clientId,
  issuer: oktaBaseUrl,
  redirect_uri: window.location.origin + '/implicit/callback',
  scope: 'openid email profile groups',
  response_type: 'token',
  nonce:'omc-fpts',
  state: 'omc-fpts'
}

const clearReload = () => {
  window.localStorage.removeItem('access_token');
  window.localStorage.removeItem('refresh_token');
  window.history.pushState(null, null, '/');
  window.location.reload(true);
}

const getNewAccessToken = () => {
  fetch(`${constants.GATEWAY}auth-service/api/v1/refresh`,{
    method: 'POST',
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      "refresh_token": window.localStorage.getItem('refresh_token')
    })
  }).then(res => res.ok ? res.text() : (() => {throw new Error(res.statusText)})()).then(res => {
    const { access_token } = JSON.parse(res);
    window.localStorage.setItem('access_token', access_token);
    setCookie('access_token', access_token);
    window.location.reload();
  }).catch(err => {
    console.error('err', err);
    logout();
  })
}

const logout = (tilaSessionExpired) => {
  if(tilaSessionExpired) {
    return getNewAccessToken()
  }
  fetch(`${oktaBaseUrl}/api/v1/sessions/me`, {
    method: 'DELETE',
    credentials: "include"
  }).then(res => {
    res.ok ? res.text() : (() => {throw new Error(res.statusText)})()
  }).then(res => {
    clearReload();
  }).catch(err => {
    clearReload();
  })
}

export {oktaBaseUrl, oktaConfig, logout}