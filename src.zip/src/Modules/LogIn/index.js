/*eslint-disable*/
import React from 'react';
import { setCookie } from '../../Services/CookieService';
import {oktaBaseUrl, oktaConfig, logout} from './authentication.service';
// import './login.css';

export default class Login extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: true
    }
  }

  componentDidMount(){
    this.checkLoginStatus();
  }

  componentWillReceiveProps(nextProps){
    if(nextProps.error) {
      this.setState({
        loading: false
      })
    }
  }

  checkLoginStatus = () => {
    const {hash} = window.location;
    (window.location.pathname === '/implicit/callback' && !!hash) ? this.storeAccessToken(hash) : this.getSession();
  }

  getSession = () => {
    if(window.localStorage.getItem('okta_access_token')) {
      fetch(`${oktaBaseUrl}/api/v1/sessions/me`, {
        method: 'GET',
        credentials: "include"
      }).then(res => res.ok ? res.text() : (() => {throw new Error(res.statusText)})()).then(res => {
        const okta_user_id = JSON.parse(res).id
        setCookie('okta_user_id', okta_user_id);
        window.localStorage.setItem('okta_user_id', okta_user_id)
        this.handleLogin();
      }).catch(err => {
        this.handleOktaLogin();
      })
    } else {
      this.handleOktaLogin();
    }
  }

  handleOktaLogin = () => {
    window.localStorage.removeItem('access_token');
    window.localStorage.removeItem('refresh_token');
    window.location.replace(`${oktaBaseUrl}/oauth2/v1/authorize?${this.getUrlEncodedParams(oktaConfig)}`)
  }

  storeAccessToken = (hash) => {
    const [key, value] = hash.split('&')[0].split('=');
    if(key === '#access_token') {
      window.localStorage.setItem('okta_access_token', value);
      window.location.replace('/');
    } else if(hash.includes('error')){
      logout();
      this.setState({
        loading: false
      })
    } else {
      this.handleOktaLogin();
    }
  }

  setCookieWithRes = (res) => {
    for(let token in res){
      setCookie(token, res[token], 7)
    }
  }

  getUserInfo = () => fetch(`${oktaBaseUrl}/oauth2/v1/userinfo`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${window.localStorage.getItem('okta_access_token')}`
      }
    })
  

  getUrlEncodedParams = (paramObj) => {
    let paramString = ''
    for(let key in paramObj){
      paramString = paramString ? `${paramString}&${encodeURIComponent(key)}=${encodeURIComponent(paramObj[key])}` : `${encodeURIComponent(key)}=${encodeURIComponent(paramObj[key])}`
    }
    return paramString;
  }

  handleChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  }

  handleLogin = () => {
    this.getUserInfo().then(res => res.ok ? res.text() : (() => {throw new Error(res.statusText)})()).then(res => {
      this.props.authLogin(res);
    }).catch(err => {
      logout();
      this.setState({
        loading: false
      })
    });
  }

  render() {
    return (
      <div style={{ height: '100vh', width: '100vw', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        {this.state.loading ? <div className='loader' /> : <div>Something went wrong, Please Refresh.</div>}
      </div>
    )
  }
}
