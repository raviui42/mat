/*eslint-disable*/
const oktaBaseUrl = {
    dev: 'https://sso.tila.com',
    stage: 'https://sso.tila.com',
    preprod: 'https://dev-364787.oktapreview.com',
    prod: 'https://dev-364787.oktapreview.com'
}[APP_ENV];

const clientId = {
    dev: '0oa4okfzmwP4vvOzU2p7',
    stage: '0oa4ffx0f4AzmeXCf2p7',
    preprod: '0oaemdthg7eUYKQ9C0h7',
    prod: '0oaemdthg7eUYKQ9C0h7'
}[APP_ENV];

export { oktaBaseUrl, clientId};