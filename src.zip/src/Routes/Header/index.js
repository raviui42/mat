/*eslint-disable*/
import React, { Component } from 'react';
import {Row, Col} from 'antd';
import './header.sass';
import MatImage from '../../MatComponents/MatImage';

const TILA_LOGO = 'TILA_LOGO';

class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (<Row className="header-container">
            <Col span={14}>
                <Col span={2}>
                    <MatImage name={TILA_LOGO} />
                </Col>
                <Col span={22} className="portal-name-container">
                    <div className="portal-name">Marketing</div>
                    <div className="portal-name">Account Terminal</div>
                </Col>
            </Col>
            <Col span={3}>Domain</Col>
            <Col span={3}>Notification</Col>
            <Col span={4}>Abhishek Sachdeva, Thumbnail</Col>
        </Row>);
    }
}
export default Header;
