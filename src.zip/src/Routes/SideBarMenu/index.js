/*eslint-disable*/
import React, { Component } from 'react';
import { Menu, Icon } from 'antd';
import { NavLink } from 'react-router-dom'; //Route
const { SubMenu } = Menu;
class SideBarNavigation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            collapsed: false,
            mode: 'inline',
            theme: 'dark',
        };
    }

    toggleCollapsed = () => {
        this.setState({ collapsed: !this.state.collapsed });
    }

    render() {
        return (
            <Menu
                style={{ width: 256 }}
                defaultSelectedKeys={['COUPON_CREATE']}
                defaultOpenKeys={['COUPON']}
                mode={this.state.mode}
                theme={this.state.theme}
            >
                {/* <Menu.Item key="1">
                    <Icon type="mail" />
                    Navigation One
          </Menu.Item> */}
                <SubMenu
                    key="COUPON"
                    title={
                        <span>
                            {/* <Icon type="appstore" /> */}
                            <span>Coupon</span>
                        </span>
                    }
                >
                    <Menu.Item key="COUPON_CREATE">
                        <NavLink to="/coupon/create">Create Coupon</NavLink>
                    </Menu.Item>
                    <Menu.Item key="COUPON_DASHBOARD">Dashboard</Menu.Item>
                </SubMenu>
                {/* <SubMenu
                    key="sub2"
                    title={
                        <span>
                            <Icon type="setting" />
                            <span>Navigation Four</span>
                        </span>
                    }
                >
                    <Menu.Item key="7">Option 7</Menu.Item>
                    <Menu.Item key="8">Option 8</Menu.Item>
                    <Menu.Item key="9">Option 9</Menu.Item>
                    <Menu.Item key="10">Option 10</Menu.Item>
                </SubMenu> */}
            </Menu>
        );
    }
}
export default SideBarNavigation;
