import React, { Component } from 'react';
import { Router, Route, Switch, Redirect } from 'react-router-dom';
import { Layout } from 'antd';
import CONSTANTS from '../mat.constants';
import './app.sass';
import { setCookie } from '../Services/CookieService';
import { getValueFromStorage, setValueToStorage } from '../Services/LocalStorageService';
import SideBarNavigation from './SideBarMenu';
import NoPageFound from '../MatComponents/NoPageFound';
import Header from './Header';
import Login from '../Modules/LogIn';
// import { isMoment } from 'moment';
import CreateCoupons from '../Modules/Coupons/CreateCoupons';
import createBrowserHistory from 'history/createBrowserHistory';
const history = createBrowserHistory();


const { Sider, Content } = Layout;

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoggedIn: false,
            userinfo: null,
            error: false
        };
    }

    authLogin = (userinfo) => {
        if (getValueFromStorage('access_token')) {
            this.setState({
                isLoggedIn: true,
                userinfo: JSON.parse(userinfo)
            })
        } else {
            fetch(`${CONSTANTS.GATEWAY}auth-service/api/v1/login/basic`, {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    auth_version: "V1",
                    type: "OKTA",
                    username: window.localStorage.getItem('okta_user_id')
                })
            }).then(res => res.ok ? res.text() : (() => { throw new Error(res.statusText) })()).then(res => {
                const { access_token, refresh_token } = JSON.parse(res);
                /**
                 * Setting access_token & refresh_token to Cookies & LocalStorage Both.
                 * So Application having no localstorage can use this code.
                 */
                setValueToStorage('access_token', access_token);
                setValueToStorage('refresh_token', refresh_token);
                setCookie('access_token', access_token);
                setCookie('refresh_token', refresh_token);
                this.setState({
                    isLoggedIn: true,
                    userinfo: JSON.parse(userinfo)
                })
            }).catch(err => {
                console.error('err', err);
                this.setState({
                    error: true
                })
            })
        }
    }

    render() {
        // const { history, auth } = this.props;
        const { userinfo, isLoggedIn } = this.state;
        return (
            <Router history={history} >
                {isLoggedIn ?
                    <Layout  className="app-container">
                        < Header />
                        <Layout>
                            <Sider id="sidebar" style={{ height: '100%', overflow: 'auto' }}><SideBarNavigation /></Sider>
                            <Content>
                                <Switch>
                                    <Route
                                        exact
                                        path="/"
                                        render={() => (
                                            <Redirect
                                                to={{
                                                    pathname: "/coupon/create",
                                                }}
                                            />
                                        )}
                                    />
                                    <Route
                                        exact
                                        path="/coupon/create"
                                        render={(props) => <CreateCoupons />}
                                    />
                                    <Route exact path="*" component={NoPageFound} />
                                </Switch>

                            </Content>
                        </Layout>
                    </Layout >
                    :
                    <Login authLogin={this.authLogin} error={this.state.error} />
                }
            </Router>
        );
    }
}

export default App;
