const setValueToStorage = (key, value) => {
    window.localStorage.setItem(key, value);
}

const getValueFromStorage = (key) => {
    return window.localStorage.getItem(key);
}

export { getValueFromStorage, setValueToStorage };