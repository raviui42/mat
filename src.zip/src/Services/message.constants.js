export const MESSAGE_CONSTANTS = {
    'NOT_AUTHORIZED': 'Restricted Access.',
    'TRY_AGAIN': 'Unable to process, Please try again later.'
}