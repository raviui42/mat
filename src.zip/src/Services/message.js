
// import {message} from 'antd';

export function matMessage(type, message) {
    switch(type){
        case 'SUCCESS':
            break;
    }
}