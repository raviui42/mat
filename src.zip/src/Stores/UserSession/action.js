import * as ACTION from './actionTypes'; 

export const createCoupon = () => ({
  type: ACTION.DOMAIN_CURRENCY_MAPPING,
  payload: '',
});
