/*eslint-disable*/
import typeToReducer from 'type-to-reducer';
import * as ACTION from './action';

const initialState = { 
  isFulfilled: false,
};


const UserSessionReducer = typeToReducer({
  [ACTION.createCoupon]: {
    PENDING: state => (Object.assign({}, state, {
      isFulfilled: false,
    })),
    FULFILLED: (state, action) => (Object.assign({}, state, {
      isFulfilled: true,
    })),
    REJECTED: (state, action) => (Object.assign({}, state, {
      isFulfilled: true,
    })),
  },
}, initialState);

export default UserSessionReducer;
