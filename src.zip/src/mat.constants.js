/*eslint-disable*/
export const API_SERVICES = ['GATEWAY', 'TRANSFORMERS', 'MAT'];

const dev = {
    GATEWAY: 'http://apigatewayinternal-dev.fptsinternal.com/',
    TRANSFORMERS: 'http://apigatewayinternal-dev.fptsinternal.com/transformers/fpts/',
    MAT: 'http://apigatewayinternal-dev.fptsinternal.com/dip/fpts/',
};

const stage = {
    GATEWAY: 'http://apigatewayinternal-stage.fptsinternal.com/',
    TRANSFORMERS: 'http://apigatewayinternal-stage.fptsinternal.com/transformers/fpts/',
    MAT: 'http://apigatewayinternal-stage.fptsinternal.com/dip/fpts/',
};


const preprod = {
    GATEWAY: 'http://apigatewayinternal-preprod.fptsinternal.com/',
    TRANSFORMERS: 'http://apigatewayinternal-preprod.fptsinternal.com/transformers/fpts',
    MAT: 'http://apigatewayinternal-stage.fptsinternal.com/dip/fpts/',
};

const prod = {
    GATEWAY: 'http://apigatewayinternal.fptsinternal.com/',
    TRANSFORMERS: 'http://apigatewayinternal.fptsinternal.com/transformers/fpts',
    MAT: 'http://apigatewayinternal-stage.fptsinternal.com/dip/fpts/',
};

export default { dev, stage, preprod, prod }[APP_ENV];
